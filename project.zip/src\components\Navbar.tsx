'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setIsOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-20 bg-[#131313]/95 backdrop-blur-xl border-b border-white/10">
      <div className="max-w-7xl mx-auto h-full px-12 flex items-center justify-between">
        
        {/* Logo */}
        <div className="flex items-center gap-3 min-w-[180px]">
          <span className="text-4xl">🍔</span>
          <div>
            <span className="font-headline font-black text-2xl tracking-tighter text-[#9F2A1F] uppercase">COSA NOSTRA</span>
            <p className="text-[10px] text-gray-500 -mt-1">SOCIAL CLUB</p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-10 text-sm font-medium uppercase tracking-widest">
          <button onClick={() => scrollTo('menu')} className="hover:text-[#9F2A1F] transition-colors">MENU</button>
          <button onClick={() => scrollTo('club')} className="hover:text-[#9F2A1F] transition-colors">EL CLUB</button>
          <button onClick={() => scrollTo('location')} className="hover:text-[#9F2A1F] transition-colors">UBICACIÓN</button>
        </nav>

        {/* WhatsApp Button */}
        <a 
          href="https://wa.me/5493548638444" 
          target="_blank"
          className="hidden md:block bg-[#9F2A1F] hover:bg-red-700 text-white px-8 py-3 font-headline font-bold uppercase tracking-widest text-sm transition-all"
        >
          PEDIR POR WHATSAPP
        </a>

        {/* Mobile Toggle */}
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden text-3xl text-white"
          aria-label="Toggle menu"
        >
          {isOpen ? '✕' : '☰'}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#131313] border-t border-white/10"
          >
            <div className="px-12 py-8 flex flex-col gap-6 text-lg">
              <button onClick={() => scrollTo('menu')} className="text-left hover:text-[#9F2A1F] transition">MENU</button>
              <button onClick={() => scrollTo('club')} className="text-left hover:text-[#9F2A1F] transition">EL CLUB</button>
              <button onClick={() => scrollTo('location')} className="text-left hover:text-[#9F2A1F] transition">UBICACIÓN</button>
              
              <a 
                href="https://wa.me/5493548638444" 
                target="_blank"
                className="mt-4 bg-[#9F2A1F] text-white py-4 text-center font-headline font-bold uppercase tracking-widest"
              >
                PEDIR POR WHATSAPP
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}