import Navbar from '@/components/Navbar';
import Hero from '@/sections/Hero';
import Menu from '@/sections/Menu';
import Club from '@/sections/Club';
import LocationSection from '@/sections/Location';
import Footer from '@/sections/Footer';

export default function CosaNostra() {
  return (
    <main>
      <Navbar />
      <Hero />
      <Menu />
      <Club />
      <LocationSection />
      <Footer />
    </main>
  );
}