export default function Hero() {
  return (
    <section className="relative h-screen flex items-center pt-20 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1551782450-a2132b4ba21d?q=80&w=2070&auto=format&fit=crop" 
          alt="Smash Burger" 
          className="w-full h-full object-cover brightness-75" 
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/70 to-black" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <h1 className="font-headline font-black text-6xl md:text-8xl leading-none tracking-tighter mb-6 text-white">
          ADICTOS A LAS<br />
          <span className="text-[#9F2A1F]">SMASH</span> BURGERS
        </h1>
        <p className="text-2xl text-gray-300 mb-12">Villa Giardino • Delivery & Takeaway</p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a 
            href="https://wa.me/5493548638444" 
            target="_blank"
            className="bg-[#9F2A1F] hover:bg-red-700 text-white px-12 py-5 font-headline font-bold uppercase tracking-widest text-lg transition"
          >
            Pedir por WhatsApp
          </a>
          <a 
            href="tel:03548638444" 
            className="border-2 border-[#9F2A1F] hover:bg-white/10 px-12 py-5 font-headline font-bold uppercase tracking-widest text-lg transition"
          >
            Llamar Ahora
          </a>
        </div>
      </div>
    </section>
  );
}