export default function Footer() {
  return (
    <footer className="bg-black py-12 text-center text-sm text-gray-500 border-t border-white/10">
      © Cosa Nostra Social Club • Portfolio Project by Gelum Digital
    </footer>
  );
}